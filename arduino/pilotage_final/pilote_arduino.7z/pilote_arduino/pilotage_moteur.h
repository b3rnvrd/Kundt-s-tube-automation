#ifndef PILOTAGE_MOTEUR_H
#define PILOTAGE_MOTEUR_H
#include "SPI.h"



void setupSerialMoteur();
void avanceGauche();
void avanceDroite();
void arretMoteur();

#endif
